This recipe shows how to display a local PDF file in a WebView control on each platform.

The full recipe can be found [here](http://developer.xamarin.com/recipes/cross-platform/xamarin-forms/controls/display-pdf/).
# DisplayingPDFinWebView
