﻿using Xamarin.Forms;

namespace DisplayingPDFinWebView
{
	public partial class WebViewPage : ContentPage
	{
		public WebViewPage()
		{
			InitializeComponent();
		}
	}
}
